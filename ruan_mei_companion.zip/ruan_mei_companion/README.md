# Ruan Mei Companion — Flutter App

A Live2D desktop companion app featuring Ruan Mei from Honkai: Star Rail.
She floats over all your apps, responds to voice via Claude AI, and uses
your actual .moc3 model files.

---

## 📁 Project Structure

```
ruan_mei_companion/
├── lib/
│   ├── main.dart                        ← App + overlay entry point
│   ├── models/app_settings.dart         ← Settings (API keys, prefs)
│   ├── services/
│   │   ├── claude_service.dart          ← Claude API chat
│   │   └── voice_service.dart           ← Whisper STT + OpenAI TTS
│   ├── screens/
│   │   ├── home_screen.dart             ← Launcher + overlay toggle
│   │   └── settings_screen.dart         ← API keys, model path, tuning
│   └── widgets/
│       ├── live2d_widget.dart           ← WebView rendering Live2D
│       └── overlay_companion_widget.dart← Draggable overlay character
├── assets/live2d/html/live2d_viewer.html← Live2D HTML renderer
├── pubspec.yaml
└── android/app/src/main/AndroidManifest.xml
```

---

## 🚀 Setup Steps

### 1. Flutter environment
```bash
flutter --version   # needs Flutter 3.19+ / Dart 3+
```

### 2. Add missing pubspec dependency
The settings screen uses `file_picker`. Add it:
```yaml
  file_picker: ^8.0.0
```

### 3. Install dependencies
```bash
cd ruan_mei_companion
flutter pub get
```

### 4. Android build config

**android/app/build.gradle** — set:
```groovy
android {
    compileSdkVersion 34
    defaultConfig {
        minSdkVersion 23       // required for overlay_window
        targetSdkVersion 34
    }
}
```

**android/build.gradle** — kotlin version:
```groovy
ext.kotlin_version = '1.9.0'
```

### 5. Place your Live2D files

Copy your Ruan Mei model files anywhere accessible on device, e.g.:
```
/sdcard/RuanMei/
  1208 ... .model3.json   ← point to this in Settings
  1208 ... .moc3
  1208 ... .physics3.json
  1208 ... .cdi3.json
  textures/               ← must be in same folder
```

Then in the app → Settings → Browse → pick the `.model3.json` file.

---

## 📱 First Run

1. **Install APK** or `flutter run`
2. **Home screen** shows 3 setup chips:
   - 🎭 Model → browse to your `.model3.json`
   - 🤖 Claude Key → paste `sk-ant-...` key
   - 🎤 OpenAI Key → paste `sk-...` key (for Whisper + TTS)
3. Tap **"Summon Ruan Mei"** → grants overlay permission
4. She appears floating over all apps!

---

## 🎤 Voice Chat Flow

```
Hold mic button → record voice
Release → Whisper transcribes
→ Claude replies (with conversation memory)
→ OpenAI TTS speaks the reply
→ Live2D lip-sync during speech
```

---

## 🎭 Live2D Rendering

The model renders inside a transparent WebView using:
- **PIXI.js v7** for the canvas renderer
- **pixi-live2d-display** which wraps Cubism SDK 4
- **Live2D Cubism Core** (loaded from CDN)

> ⚠️ The Cubism SDK requires internet on first render since it loads
> from `cubism.live2d.com`. For offline use, download and bundle
> `live2dcubismcore.min.js` locally.

### Motion names (auto-mapped)
The app tries these motion group names in order:
| State  | Tries               |
|--------|---------------------|
| idle   | Idle, idle_01, idle |
| walk   | Walk, walk, Move    |
| sit    | Sit, sit, Rest      |
| sleep  | Sleep, sleep, Relax |
| talk   | Talk, talk, Speak   |

Check your `.model3.json` → `"Motions"` section for exact group names
and update `MOTION_MAP` in `live2d_viewer.html` if needed.

---

## ⚙️ Behavior

| Feature | Detail |
|---------|--------|
| Drag | Pan anywhere on screen |
| Gravity snap | Snaps to left/right edge after release |
| Keyboard aware | Moves up when keyboard opens, returns after |
| Idle wander | Randomly switches idle/sit every ~8s |
| Talk lip-sync | Oscillates `ParamMouthOpenY` during TTS |

---

## 🔑 API Keys

| Key | Where to get |
|-----|-------------|
| Claude | https://console.anthropic.com → API Keys |
| OpenAI | https://platform.openai.com → API Keys |

Keys are stored locally via `shared_preferences` (not encrypted by default).
For production, switch to `flutter_secure_storage` — the model already imports it.

---

## 🛠 Troubleshooting

**Model doesn't load**
- Check `.moc3`, `.physics3.json`, textures are in the same folder as `.model3.json`
- Enable WebView debug: `chrome://inspect` while connected via USB

**Overlay doesn't appear**
- Android Settings → Apps → Ruan Mei → Display over other apps → Enable

**Mic not working**
- Settings → Apps → Ruan Mei → Permissions → Microphone → Allow

**Motion not playing**
- Open `live2d_viewer.html` in browser DevTools
- Check console for motion group names vs your `.model3.json`

---

## 📦 Building Release APK

```bash
flutter build apk --release --target-platform android-arm64
# Output: build/app/outputs/flutter-apk/app-release.apk
```
