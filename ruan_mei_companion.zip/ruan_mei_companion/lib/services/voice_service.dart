import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';

class VoiceService {
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  String? _recordingPath;
  bool _isRecording = false;
  bool _isPlaying = false;

  bool get isRecording => _isRecording;
  bool get isPlaying => _isPlaying;

  // Callbacks
  Function(bool)? onPlayingChanged;
  Function(bool)? onRecordingChanged;

  Future<void> init() async {
    _player.onPlayerStateChanged.listen((state) {
      _isPlaying = state == PlayerState.playing;
      onPlayingChanged?.call(_isPlaying);
    });
  }

  /// Start recording audio from microphone
  Future<bool> startRecording() async {
    if (_isRecording) return false;

    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) return false;

    final dir = await getTemporaryDirectory();
    _recordingPath = '${dir.path}/ruan_mei_input_${DateTime.now().millisecondsSinceEpoch}.m4a';

    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        sampleRate: 16000,
        numChannels: 1,
        bitRate: 128000,
      ),
      path: _recordingPath!,
    );

    _isRecording = true;
    onRecordingChanged?.call(true);
    return true;
  }

  /// Stop recording and return the file path
  Future<String?> stopRecording() async {
    if (!_isRecording) return null;

    final path = await _recorder.stop();
    _isRecording = false;
    onRecordingChanged?.call(false);
    return path;
  }

  /// Transcribe audio using OpenAI Whisper API
  Future<String> transcribeAudio(String filePath, String apiKey) async {
    final file = File(filePath);
    if (!await file.exists()) throw Exception('Audio file not found');

    final request = http.MultipartRequest(
      'POST',
      Uri.parse('https://api.openai.com/v1/audio/transcriptions'),
    );

    request.headers['Authorization'] = 'Bearer $apiKey';
    request.files.add(await http.MultipartFile.fromPath(
      'file',
      filePath,
      filename: 'audio.m4a',
    ));
    request.fields['model'] = 'whisper-1';
    request.fields['language'] = 'en';

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['text'] as String? ?? '';
    } else {
      throw Exception('Whisper API error ${response.statusCode}: ${response.body}');
    }
  }

  /// Convert text to speech using OpenAI TTS API
  Future<void> speak(String text, String apiKey, {String voice = 'nova'}) async {
    if (text.isEmpty) return;

    // Stop any current playback
    await _player.stop();

    final response = await http.post(
      Uri.parse('https://api.openai.com/v1/audio/speech'),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'tts-1',
        'voice': voice,
        'input': text,
        'speed': 0.95,
      }),
    );

    if (response.statusCode == 200) {
      // Save audio to temp file
      final dir = await getTemporaryDirectory();
      final audioFile = File('${dir.path}/ruan_mei_tts_${DateTime.now().millisecondsSinceEpoch}.mp3');
      await audioFile.writeAsBytes(response.bodyBytes);

      // Play the audio
      _isPlaying = true;
      onPlayingChanged?.call(true);
      await _player.play(DeviceFileSource(audioFile.path));
    } else {
      throw Exception('TTS API error ${response.statusCode}: ${response.body}');
    }
  }

  Future<void> stopSpeaking() async {
    await _player.stop();
    _isPlaying = false;
    onPlayingChanged?.call(false);
  }

  Future<void> dispose() async {
    await _recorder.dispose();
    await _player.dispose();
  }
}
