import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';
import '../models/app_settings.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _claudeKeyCtrl;
  late TextEditingController _openAiKeyCtrl;
  late TextEditingController _systemPromptCtrl;
  bool _claudeObscure = true;
  bool _openAiObscure = true;

  static const _voices = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'];
  static const _models = [
    'claude-opus-4-5',
    'claude-sonnet-4-5',
    'claude-haiku-4-5-20251001',
  ];

  @override
  void initState() {
    super.initState();
    final s = context.read<AppSettings>();
    _claudeKeyCtrl = TextEditingController(text: s.claudeApiKey);
    _openAiKeyCtrl = TextEditingController(text: s.openAiApiKey);
    _systemPromptCtrl = TextEditingController(text: s.systemPrompt);
  }

  @override
  void dispose() {
    _claudeKeyCtrl.dispose();
    _openAiKeyCtrl.dispose();
    _systemPromptCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickModelFile(AppSettings settings) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      dialogTitle: 'Select .model3.json file',
    );
    if (result != null && result.files.single.path != null) {
      final path = result.files.single.path!;
      if (path.endsWith('.model3.json')) {
        await settings.setModelPath(path);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Model loaded ✓'), backgroundColor: Color(0xFF6B3A5A)),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Please select a .model3.json file'), backgroundColor: Colors.red),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();

    return Scaffold(
      backgroundColor: const Color(0xFF1A0E1A),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 140,
            pinned: true,
            backgroundColor: const Color(0xFF2D1A2D),
            flexibleSpace: FlexibleSpaceBar(
              title: const Text(
                'Companion Settings',
                style: TextStyle(
                  color: Color(0xFFEDD5EA),
                  fontSize: 18,
                  fontWeight: FontWeight.w300,
                  letterSpacing: 1.2,
                ),
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF3D1E3D), Color(0xFF1A0E1A)],
                  ),
                ),
                child: Center(
                  child: Opacity(
                    opacity: 0.15,
                    child: Text(
                      '瑞梅',
                      style: TextStyle(
                        fontSize: 80,
                        color: const Color(0xFFE8C8DC),
                        fontWeight: FontWeight.w100,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── Live2D Model ───────────────────────────────────────────
                _SectionHeader(title: '🎭  Live2D Model'),
                _SettingsCard(children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Model File (.model3.json)',
                        style: TextStyle(color: Color(0xFFEDD5EA), fontSize: 14)),
                    subtitle: Text(
                      settings.modelPath.isEmpty
                          ? 'No model selected'
                          : settings.modelPath.split('/').last,
                      style: TextStyle(
                        color: settings.modelPath.isEmpty
                            ? Colors.grey
                            : const Color(0xFFD4A8C7),
                        fontSize: 12,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: ElevatedButton.icon(
                      onPressed: () => _pickModelFile(settings),
                      icon: const Icon(Icons.folder_open_rounded, size: 16),
                      label: const Text('Browse'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B3A5A),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        textStyle: const TextStyle(fontSize: 12),
                      ),
                    ),
                  ),
                  if (settings.modelPath.isNotEmpty) ...[
                    const Divider(color: Color(0xFF4A2A4A)),
                    _InfoTile(
                      label: 'Files needed in same folder:',
                      value: '.moc3 · .cdi3.json · .physics3.json · textures/',
                    ),
                  ],
                ]),

                const SizedBox(height: 16),

                // ── Claude API ─────────────────────────────────────────────
                _SectionHeader(title: '🤖  Claude AI (for responses)'),
                _SettingsCard(children: [
                  _ApiKeyField(
                    label: 'Claude API Key',
                    hint: 'sk-ant-...',
                    controller: _claudeKeyCtrl,
                    obscure: _claudeObscure,
                    isSet: settings.hasClaudeKey,
                    onToggleObscure: () => setState(() => _claudeObscure = !_claudeObscure),
                    onSave: () => settings.setClaudeApiKey(_claudeKeyCtrl.text.trim()),
                  ),
                  const Divider(color: Color(0xFF4A2A4A)),
                  _DropdownTile<String>(
                    label: 'Claude Model',
                    value: settings.claudeModel,
                    items: _models,
                    onChanged: settings.setClaudeModel,
                  ),
                ]),

                const SizedBox(height: 16),

                // ── OpenAI API ─────────────────────────────────────────────
                _SectionHeader(title: '🎤  Voice (Whisper STT + TTS)'),
                _SettingsCard(children: [
                  _ApiKeyField(
                    label: 'OpenAI API Key',
                    hint: 'sk-...',
                    controller: _openAiKeyCtrl,
                    obscure: _openAiObscure,
                    isSet: settings.hasOpenAiKey,
                    onToggleObscure: () => setState(() => _openAiObscure = !_openAiObscure),
                    onSave: () => settings.setOpenAiApiKey(_openAiKeyCtrl.text.trim()),
                  ),
                  const Divider(color: Color(0xFF4A2A4A)),
                  _DropdownTile<String>(
                    label: 'TTS Voice',
                    value: settings.ttsVoice,
                    items: _voices,
                    onChanged: settings.setTtsVoice,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'nova / shimmer are most feminine',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 11),
                  ),
                ]),

                const SizedBox(height: 16),

                // ── Personality ────────────────────────────────────────────
                _SectionHeader(title: '✨  Ruan Mei\'s Personality'),
                _SettingsCard(children: [
                  Text('System Prompt',
                      style: TextStyle(color: const Color(0xFFEDD5EA).withOpacity(0.7), fontSize: 12)),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _systemPromptCtrl,
                    maxLines: 5,
                    style: const TextStyle(color: Color(0xFFEDD5EA), fontSize: 12),
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: const Color(0xFF120A12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFF4A2A4A)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFF4A2A4A)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Color(0xFFD4A8C7)),
                      ),
                    ),
                    onChanged: (_) {},
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton(
                      onPressed: () => settings.setSystemPrompt(_systemPromptCtrl.text),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF6B3A5A),
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Save Prompt'),
                    ),
                  ),
                ]),

                const SizedBox(height: 16),

                // ── Behavior ───────────────────────────────────────────────
                _SectionHeader(title: '⚙️  Behavior'),
                _SettingsCard(children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Gravity Snap to Edges',
                        style: TextStyle(color: Color(0xFFEDD5EA), fontSize: 14)),
                    subtitle: const Text('Snaps to screen edges after drag',
                        style: TextStyle(color: Colors.grey, fontSize: 12)),
                    value: settings.gravitySnap,
                    activeColor: const Color(0xFFD4A8C7),
                    onChanged: settings.setGravitySnap,
                  ),
                  const Divider(color: Color(0xFF4A2A4A)),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Character Size',
                        style: TextStyle(color: Color(0xFFEDD5EA), fontSize: 14)),
                    subtitle: Slider(
                      value: settings.overlaySize,
                      min: 120,
                      max: 320,
                      divisions: 20,
                      activeColor: const Color(0xFFD4A8C7),
                      onChanged: settings.setOverlaySize,
                    ),
                  ),
                ]),

                const SizedBox(height: 24),

                // ── Status ─────────────────────────────────────────────────
                _StatusRow(settings: settings),

                const SizedBox(height: 32),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── REUSABLE COMPONENTS ────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8, left: 2),
    child: Text(title,
        style: const TextStyle(
          color: Color(0xFFD4A8C7),
          fontSize: 13,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        )),
  );
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: const Color(0xFF261A26),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: const Color(0xFF3D2A3D), width: 1),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: children,
    ),
  );
}

class _ApiKeyField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final bool obscure;
  final bool isSet;
  final VoidCallback onToggleObscure;
  final VoidCallback onSave;

  const _ApiKeyField({
    required this.label,
    required this.hint,
    required this.controller,
    required this.obscure,
    required this.isSet,
    required this.onToggleObscure,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label,
                style: TextStyle(color: const Color(0xFFEDD5EA).withOpacity(0.7), fontSize: 12)),
            const SizedBox(width: 8),
            if (isSet)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: const Color(0xFF2A5A2A),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text('✓ Set', style: TextStyle(color: Color(0xFF80E080), fontSize: 10)),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                obscureText: obscure,
                style: const TextStyle(color: Color(0xFFEDD5EA), fontSize: 12, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: TextStyle(color: Colors.grey.shade700, fontSize: 12),
                  filled: true,
                  fillColor: const Color(0xFF120A12),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF4A2A4A)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF4A2A4A)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFFD4A8C7)),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(obscure ? Icons.visibility_off : Icons.visibility,
                        size: 18, color: Colors.grey),
                    onPressed: onToggleObscure,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: onSave,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6B3A5A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
              child: const Text('Save', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
      ],
    );
  }
}

class _DropdownTile<T> extends StatelessWidget {
  final String label;
  final T value;
  final List<T> items;
  final void Function(T) onChanged;

  const _DropdownTile({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(label,
            style: TextStyle(color: const Color(0xFFEDD5EA).withOpacity(0.7), fontSize: 13)),
        const Spacer(),
        DropdownButton<T>(
          value: value,
          dropdownColor: const Color(0xFF2D1A2D),
          style: const TextStyle(color: Color(0xFFD4A8C7), fontSize: 13),
          underline: const SizedBox(),
          items: items.map((v) => DropdownMenuItem<T>(
            value: v,
            child: Text(v.toString()),
          )).toList(),
          onChanged: (v) { if (v != null) onChanged(v); },
        ),
      ],
    );
  }
}

class _InfoTile extends StatelessWidget {
  final String label;
  final String value;
  const _InfoTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(color: Colors.grey, fontSize: 11)),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(color: Color(0xFFD4A8C7), fontSize: 11, fontFamily: 'monospace')),
    ],
  );
}

class _StatusRow extends StatelessWidget {
  final AppSettings settings;
  const _StatusRow({required this.settings});

  @override
  Widget build(BuildContext context) {
    final checks = [
      ('Model', settings.modelPath.isNotEmpty),
      ('Claude Key', settings.hasClaudeKey),
      ('OpenAI Key', settings.hasOpenAiKey),
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF261A26),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF3D2A3D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Setup Status',
              style: TextStyle(color: Color(0xFFD4A8C7), fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          ...checks.map((c) => Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                Icon(
                  c.$2 ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                  size: 16,
                  color: c.$2 ? const Color(0xFF80E080) : Colors.grey,
                ),
                const SizedBox(width: 8),
                Text(c.$1,
                    style: TextStyle(
                      color: c.$2 ? const Color(0xFFEDD5EA) : Colors.grey,
                      fontSize: 13,
                    )),
              ],
            ),
          )),
          if (checks.every((c) => c.$2))
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                '✨ All set! Launch the overlay from the home screen.',
                style: TextStyle(color: Color(0xFFD4A8C7), fontSize: 12),
              ),
            ),
        ],
      ),
    );
  }
}
