import 'dart:convert';
import 'package:http/http.dart' as http;

class ClaudeService {
  static const _baseUrl = 'https://api.anthropic.com/v1/messages';

  final String apiKey;
  final String model;
  final String systemPrompt;

  // Conversation history for context
  final List<Map<String, String>> _history = [];
  static const int _maxHistory = 10; // keep last 10 exchanges

  ClaudeService({
    required this.apiKey,
    required this.model,
    required this.systemPrompt,
  });

  Future<String> sendMessage(String userMessage) async {
    // Add user message to history
    _history.add({'role': 'user', 'content': userMessage});

    // Keep history bounded
    while (_history.length > _maxHistory * 2) {
      _history.removeAt(0);
    }

    final response = await http.post(
      Uri.parse(_baseUrl),
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: jsonEncode({
        'model': model,
        'max_tokens': 300,
        'system': systemPrompt,
        'messages': _history,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final reply = data['content'][0]['text'] as String;

      // Add assistant reply to history
      _history.add({'role': 'assistant', 'content': reply});

      return reply;
    } else {
      final error = jsonDecode(response.body);
      throw Exception('Claude API error ${response.statusCode}: ${error['error']?['message'] ?? response.body}');
    }
  }

  void clearHistory() {
    _history.clear();
  }
}
