import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:path/path.dart' as p;

class Live2DWidget extends StatefulWidget {
  final String modelJsonPath;
  final double width;
  final double height;
  final VoidCallback? onModelReady;
  final Function(String)? onError;

  const Live2DWidget({
    super.key,
    required this.modelJsonPath,
    required this.width,
    required this.height,
    this.onModelReady,
    this.onError,
  });

  @override
  State<Live2DWidget> createState() => Live2DWidgetState();
}

class Live2DWidgetState extends State<Live2DWidget> {
  InAppWebViewController? _controller;
  bool _modelLoaded = false;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.width,
      height: widget.height,
      child: InAppWebView(
        initialFile: 'assets/live2d/html/live2d_viewer.html',
        initialSettings: InAppWebViewSettings(
          transparentBackground: true,
          allowFileAccessFromFileURLs: true,
          allowUniversalAccessFromFileURLs: true,
          javaScriptEnabled: true,
          mediaPlaybackRequiresUserGesture: false,
          allowContentAccess: true,
          useHybridComposition: true,
          hardwareAcceleration: true,
        ),
        onWebViewCreated: (controller) {
          _controller = controller;

          // JS -> Flutter channel
          controller.addJavaScriptHandler(
            handlerName: 'FlutterChannel',
            callback: (args) {
              try {
                final data = args.isNotEmpty
                    ? jsonDecode(args[0] as String)
                    : {};
                _handleJsMessage(data as Map<String, dynamic>);
              } catch (e) {
                debugPrint('JS message parse error: $e');
              }
            },
          );
        },
        onLoadStop: (controller, url) async {
          await _initModel();
        },
        onConsoleMessage: (controller, message) {
          debugPrint('Live2D WebView: ${message.message}');
        },
      ),
    );
  }

  Future<void> _initModel() async {
    if (widget.modelJsonPath.isEmpty) return;

    final modelFile = File(widget.modelJsonPath);
    if (!await modelFile.exists()) {
      widget.onError?.call('Model file not found: ${widget.modelJsonPath}');
      return;
    }

    // Build a file:// URL for the model JSON
    // The WebView needs to access local files
    final modelUrl = 'file://${widget.modelJsonPath}';

    final initMsg = jsonEncode({
      'type': 'init',
      'modelPath': p.dirname(widget.modelJsonPath),
      'modelJson': modelUrl,
    });

    await _controller?.evaluateJavascript(source: '''
      window.postMessage($initMsg, '*');
    ''');
  }

  void _handleJsMessage(Map<String, dynamic> data) {
    switch (data['type']) {
      case 'ready':
        _modelLoaded = true;
        widget.onModelReady?.call();
        break;
      case 'error':
        widget.onError?.call(data['message'] as String? ?? 'Unknown error');
        break;
    }
  }

  // ─── PUBLIC CONTROL METHODS ─────────────────────────────────────────────

  Future<void> playMotion(String name) async {
    await _controller?.evaluateJavascript(source: '''
      window.postMessage(${jsonEncode({'type': 'motion', 'name': name})}, '*');
    ''');
  }

  Future<void> setExpression(String name) async {
    await _controller?.evaluateJavascript(source: '''
      window.postMessage(${jsonEncode({'type': 'expression', 'name': name})}, '*');
    ''');
  }

  Future<void> setTalking(bool talking) async {
    await _controller?.evaluateJavascript(source: '''
      window.postMessage(${jsonEncode({'type': 'talking', 'value': talking})}, '*');
    ''');
  }
}
