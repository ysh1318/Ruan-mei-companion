import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:provider/provider.dart';
import 'models/app_settings.dart';
import 'screens/home_screen.dart';
import 'widgets/overlay_companion_widget.dart';

// ─── OVERLAY ENTRY POINT ────────────────────────────────────────────────────
// Flutter overlay_window calls this function in a separate isolate/engine
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  // Make status bar transparent inside overlay
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
  ));
  runApp(const _OverlayApp());
}

class _OverlayApp extends StatelessWidget {
  const _OverlayApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const OverlayCompanionWidget(),
    );
  }
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  final settings = AppSettings();
  await settings.load();

  runApp(
    ChangeNotifierProvider.value(
      value: settings,
      child: const RuanMeiApp(),
    ),
  );
}

class RuanMeiApp extends StatelessWidget {
  const RuanMeiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ruan Mei Companion',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFFD4A8C7),
          secondary: const Color(0xFF8B4A6B),
          surface: const Color(0xFF261A26),
          background: const Color(0xFF100810),
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
