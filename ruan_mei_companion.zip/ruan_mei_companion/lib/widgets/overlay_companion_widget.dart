import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:provider/provider.dart';

import '../models/app_settings.dart';
import '../services/claude_service.dart';
import '../services/voice_service.dart';
import 'live2d_widget.dart';

/// This widget is the entry point for the overlay window.
/// It runs in a separate Flutter engine from the main app.
class OverlayCompanionWidget extends StatefulWidget {
  const OverlayCompanionWidget({super.key});

  @override
  State<OverlayCompanionWidget> createState() => _OverlayCompanionWidgetState();
}

class _OverlayCompanionWidgetState extends State<OverlayCompanionWidget>
    with TickerProviderStateMixin {
  // Position
  late double _x;
  late double _y;
  double _screenW = 400;
  double _screenH = 800;
  bool _snappedLeft = false;

  // Character size
  static const double _charW = 180.0;
  static const double _charH = 280.0;

  // Keyboard offset animation
  late AnimationController _keyboardAnimController;
  late Animation<double> _keyboardOffsetAnim;
  double _keyboardHeight = 0;

  // State
  String _currentMotion = 'idle';
  bool _isTalking = false;
  bool _isRecording = false;
  bool _isThinking = false;
  bool _showMicButton = false;
  String _subtitleText = '';

  // Services
  late VoiceService _voiceService;
  ClaudeService? _claudeService;
  AppSettings? _settings;

  // Live2D key for control
  final GlobalKey<Live2DWidgetState> _live2dKey = GlobalKey();

  // Gravity snap animation
  late AnimationController _snapController;
  late Animation<double> _snapXAnim;
  late Animation<double> _snapYAnim;

  // Walk animation timer
  Timer? _walkTimer;
  Timer? _idleTimer;

  StreamSubscription<bool>? _keyboardSub;

  @override
  void initState() {
    super.initState();
    _x = 100;
    _y = 500;

    _keyboardAnimController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _keyboardOffsetAnim = Tween<double>(begin: 0, end: 0).animate(
      CurvedAnimation(parent: _keyboardAnimController, curve: Curves.easeOut),
    );

    _snapController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _snapXAnim = Tween<double>(begin: 0, end: 0).animate(_snapController);
    _snapYAnim = Tween<double>(begin: 0, end: 0).animate(_snapController);

    _voiceService = VoiceService();
    _voiceService.init();
    _voiceService.onPlayingChanged = (playing) {
      if (mounted) {
        setState(() => _isTalking = playing);
        _live2dKey.currentState?.setTalking(playing);
        if (!playing) _setMotion('idle');
      }
    };

    _setupKeyboardListener();
    _startIdleWander();

    // Listen for messages from main app (settings updates etc)
    FlutterOverlayWindow.overlayListener.listen((data) {
      if (data is Map) {
        _handleOverlayMessage(Map<String, dynamic>.from(data));
      }
    });
  }

  void _setupKeyboardListener() {
    final controller = KeyboardVisibilityController();
    _keyboardSub = controller.onChange.listen((visible) {
      if (!mounted) return;
      if (visible) {
        // Move character up above keyboard
        final targetY = _screenH * 0.35;
        _animateSnapTo(_x, targetY);
        _setMotion('idle');
      } else {
        // Return to bottom
        final targetY = _screenH - _charH - 20;
        _animateSnapTo(_x, targetY);
      }
    });
  }

  void _startIdleWander() {
    _idleTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (!_isTalking && !_isRecording && !_isThinking && mounted) {
        final motions = ['idle', 'idle', 'idle', 'sit'];
        final pick = motions[(DateTime.now().millisecond % motions.length)];
        _setMotion(pick);
      }
    });
  }

  void _handleOverlayMessage(Map<String, dynamic> data) {
    switch (data['type']) {
      case 'settings_update':
        // Reload settings
        _loadSettings();
        break;
      case 'close':
        FlutterOverlayWindow.closeOverlay();
        break;
    }
  }

  Future<void> _loadSettings() async {
    final settings = AppSettings();
    await settings.load();
    _settings = settings;

    if (settings.hasClaudeKey) {
      _claudeService = ClaudeService(
        apiKey: settings.claudeApiKey,
        model: settings.claudeModel,
        systemPrompt: settings.systemPrompt,
      );
    }
    if (mounted) setState(() {});
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final size = MediaQuery.of(context).size;
    _screenW = size.width;
    _screenH = size.height;

    // Initial position: bottom-center
    _x = (_screenW - _charW) / 2;
    _y = _screenH - _charH - 30;

    _loadSettings();
  }

  void _setMotion(String name) {
    if (_currentMotion == name) return;
    _currentMotion = name;
    _live2dKey.currentState?.playMotion(name);
  }

  void _animateSnapTo(double targetX, double targetY) {
    _snapXAnim = Tween<double>(begin: _x, end: targetX).animate(
      CurvedAnimation(parent: _snapController, curve: Curves.elasticOut),
    );
    _snapYAnim = Tween<double>(begin: _y, end: targetY).animate(
      CurvedAnimation(parent: _snapController, curve: Curves.elasticOut),
    );
    _snapController.forward(from: 0);
    _snapController.addListener(() {
      if (mounted) setState(() {
        _x = _snapXAnim.value;
        _y = _snapYAnim.value;
      });
    });
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (mounted) {
      setState(() {
        _x = (_x + details.delta.dx).clamp(0, _screenW - _charW);
        _y = (_y + details.delta.dy).clamp(0, _screenH - _charH);
      });

      // Walking animation while dragging horizontally
      if (details.delta.dx.abs() > 1) {
        _setMotion('walk');
        _walkTimer?.cancel();
        _walkTimer = Timer(const Duration(milliseconds: 500), () {
          _setMotion('idle');
        });
      }
    }
  }

  void _onDragEnd(DragEndDetails details) {
    if (_settings?.gravitySnap == false) return;

    // Snap to nearest horizontal edge
    final midX = _screenW / 2;
    final snapToLeft = _x + _charW / 2 < midX;
    final targetX = snapToLeft ? 0.0 : (_screenW - _charW);

    // Snap to bottom of screen (gravity)
    double targetY = _y;
    if (_y > _screenH * 0.6) {
      targetY = _screenH - _charH - 20;
    }

    _snappedLeft = snapToLeft;
    _animateSnapTo(targetX, targetY);
    _setMotion('idle');
  }

  void _onTap() {
    setState(() => _showMicButton = !_showMicButton);
  }

  Future<void> _onMicPressed() async {
    if (_isRecording) {
      await _stopAndProcess();
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    setState(() {
      _isRecording = true;
      _subtitleText = '🎤 Listening...';
    });
    _setMotion('idle');
    final success = await _voiceService.startRecording();
    if (!success) {
      setState(() {
        _isRecording = false;
        _subtitleText = '⚠️ Mic permission denied';
      });
      Timer(const Duration(seconds: 2), () {
        if (mounted) setState(() => _subtitleText = '');
      });
    }
  }

  Future<void> _stopAndProcess() async {
    final settings = _settings;
    if (settings == null) return;

    setState(() {
      _isRecording = false;
      _isThinking = true;
      _subtitleText = '💭 Thinking...';
    });

    try {
      // Stop recording
      final audioPath = await _voiceService.stopRecording();
      if (audioPath == null || audioPath.isEmpty) {
        throw Exception('No audio recorded');
      }

      // Transcribe with Whisper
      setState(() => _subtitleText = '🔄 Transcribing...');
      final transcript = await _voiceService.transcribeAudio(
        audioPath,
        settings.openAiApiKey,
      );

      if (transcript.trim().isEmpty) {
        setState(() {
          _isThinking = false;
          _subtitleText = '(no speech detected)';
        });
        Timer(const Duration(seconds: 2), () {
          if (mounted) setState(() => _subtitleText = '');
        });
        return;
      }

      setState(() => _subtitleText = '👤 "$transcript"');

      // Send to Claude
      if (_claudeService == null) {
        throw Exception('Claude API key not set');
      }

      final reply = await _claudeService!.sendMessage(transcript);

      setState(() {
        _isThinking = false;
        _subtitleText = reply;
      });

      // Speak the reply
      _setMotion('talk');
      await _voiceService.speak(reply, settings.openAiApiKey, voice: settings.ttsVoice);

      // Clear subtitle after a delay
      Timer(const Duration(seconds: 4), () {
        if (mounted) setState(() => _subtitleText = '');
      });

    } catch (e) {
      setState(() {
        _isThinking = false;
        _subtitleText = '⚠️ ${e.toString().substring(0, (e.toString().length).clamp(0, 60))}';
      });
      _setMotion('idle');
      Timer(const Duration(seconds: 3), () {
        if (mounted) setState(() => _subtitleText = '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = _settings;

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          // ── Character ────────────────────────────────────────────────────
          Positioned(
            left: _x,
            top: _y,
            child: GestureDetector(
              onPanUpdate: _onDragUpdate,
              onPanEnd: _onDragEnd,
              onTap: _onTap,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Subtitle bubble
                  if (_subtitleText.isNotEmpty)
                    _SubtitleBubble(
                      text: _subtitleText,
                      width: _charW + 40,
                    ),

                  // Loading/thinking indicator
                  if (_isThinking)
                    const Padding(
                      padding: EdgeInsets.only(bottom: 4),
                      child: SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFFE8B4D0),
                        ),
                      ),
                    ),

                  // Live2D character
                  SizedBox(
                    width: _charW,
                    height: _charH,
                    child: settings?.modelPath.isNotEmpty == true
                        ? Live2DWidget(
                            key: _live2dKey,
                            modelJsonPath: settings!.modelPath,
                            width: _charW,
                            height: _charH,
                            onModelReady: () {
                              debugPrint('Ruan Mei model loaded ✓');
                            },
                            onError: (err) {
                              debugPrint('Model error: $err');
                              setState(() => _subtitleText = '⚠️ $err');
                            },
                          )
                        : _PlaceholderCharacter(
                            width: _charW,
                            height: _charH,
                          ),
                  ),
                ],
              ),
            ),
          ),

          // ── Mic Button ──────────────────────────────────────────────────
          if (_showMicButton)
            Positioned(
              left: _x + _charW / 2 - 28,
              top: _y + _charH + 8,
              child: _MicButton(
                isRecording: _isRecording,
                hasApiKeys: settings?.hasOpenAiKey == true && settings?.hasClaudeKey == true,
                onPressed: _onMicPressed,
                onSettingsTap: () {
                  FlutterOverlayWindow.closeOverlay();
                },
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _keyboardAnimController.dispose();
    _snapController.dispose();
    _walkTimer?.cancel();
    _idleTimer?.cancel();
    _keyboardSub?.cancel();
    _voiceService.dispose();
    super.dispose();
  }
}

// ─── SUBTITLE BUBBLE ────────────────────────────────────────────────────────

class _SubtitleBubble extends StatelessWidget {
  final String text;
  final double width;

  const _SubtitleBubble({required this.text, required this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxWidth: width),
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xF0F8E8F5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFD4A8C7), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 11,
          color: Color(0xFF4A2040),
          fontFamily: 'sans-serif',
        ),
        maxLines: 5,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }
}

// ─── MIC BUTTON ─────────────────────────────────────────────────────────────

class _MicButton extends StatelessWidget {
  final bool isRecording;
  final bool hasApiKeys;
  final VoidCallback onPressed;
  final VoidCallback onSettingsTap;

  const _MicButton({
    required this.isRecording,
    required this.hasApiKeys,
    required this.onPressed,
    required this.onSettingsTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Mic button
        GestureDetector(
          onTap: hasApiKeys ? onPressed : null,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isRecording
                  ? const Color(0xFFE05080)
                  : hasApiKeys
                      ? const Color(0xFFD4A8C7)
                      : Colors.grey.shade400,
              boxShadow: [
                BoxShadow(
                  color: (isRecording ? const Color(0xFFE05080) : const Color(0xFFD4A8C7))
                      .withOpacity(0.4),
                  blurRadius: 12,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Icon(
              isRecording ? Icons.stop_rounded : Icons.mic_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
        ),

        const SizedBox(width: 8),

        // Settings shortcut
        GestureDetector(
          onTap: onSettingsTap,
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.9),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 6,
                ),
              ],
            ),
            child: const Icon(
              Icons.settings_rounded,
              color: Color(0xFF8B4A6B),
              size: 18,
            ),
          ),
        ),
      ],
    );
  }
}

// ─── PLACEHOLDER CHARACTER (when no model loaded) ───────────────────────────

class _PlaceholderCharacter extends StatefulWidget {
  final double width;
  final double height;

  const _PlaceholderCharacter({required this.width, required this.height});

  @override
  State<_PlaceholderCharacter> createState() => _PlaceholderCharacterState();
}

class _PlaceholderCharacterState extends State<_PlaceholderCharacter>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _float;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    _float = Tween<double>(begin: -6, end: 6).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _float,
      builder: (_, __) => Transform.translate(
        offset: Offset(0, _float.value),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(
                    colors: [Color(0xFFE8C8DC), Color(0xFFB87AA0)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFB87AA0).withOpacity(0.5),
                      blurRadius: 20,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: const Center(
                  child: Text('瑞梅', style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w300,
                  )),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Set model path\nin settings',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }
}
