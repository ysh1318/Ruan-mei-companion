import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import '../models/app_settings.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  bool _overlayActive = false;
  bool _hasOverlayPermission = false;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    final hasPermission = await FlutterOverlayWindow.isPermissionGranted();
    if (mounted) setState(() => _hasOverlayPermission = hasPermission);
  }

  Future<void> _requestOverlayPermission() async {
    await FlutterOverlayWindow.requestPermission();
    await _checkPermissions();
  }

  Future<void> _requestMicPermission() async {
    await Permission.microphone.request();
  }

  Future<void> _toggleOverlay(AppSettings settings) async {
    if (!_hasOverlayPermission) {
      await _requestOverlayPermission();
      return;
    }

    if (_overlayActive) {
      await FlutterOverlayWindow.closeOverlay();
      setState(() => _overlayActive = false);
    } else {
      // Launch overlay
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'Ruan Mei',
        overlayContent: 'Companion active',
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        width: WindowSize.matchParent,
        height: WindowSize.matchParent,
      );
      setState(() => _overlayActive = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final allSet = settings.modelPath.isNotEmpty &&
        settings.hasClaudeKey &&
        settings.hasOpenAiKey;

    return Scaffold(
      backgroundColor: const Color(0xFF100810),
      body: Stack(
        children: [
          // Background gradient
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment(0, -0.3),
                radius: 1.2,
                colors: [Color(0xFF2D1535), Color(0xFF100810)],
              ),
            ),
          ),

          // Decorative circles
          Positioned(
            top: -60,
            right: -60,
            child: _DecorativeCircle(size: 200, opacity: 0.08),
          ),
          Positioned(
            bottom: 100,
            left: -40,
            child: _DecorativeCircle(size: 150, opacity: 0.05),
          ),

          // Main content
          SafeArea(
            child: Column(
              children: [
                // Top bar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Ruan Mei',
                        style: TextStyle(
                          color: Color(0xFFEDD5EA),
                          fontSize: 24,
                          fontWeight: FontWeight.w200,
                          letterSpacing: 3,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SettingsScreen()),
                        ),
                        icon: const Icon(Icons.settings_outlined,
                            color: Color(0xFFD4A8C7)),
                      ),
                    ],
                  ),
                ),

                const Spacer(),

                // Character preview + launch button
                Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Animated orb / character preview
                      AnimatedBuilder(
                        animation: _pulse,
                        builder: (_, __) => Transform.scale(
                          scale: _pulse.value,
                          child: Container(
                            width: 160,
                            height: 160,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const RadialGradient(
                                colors: [Color(0xFFE8C8DC), Color(0xFF8B4A6B), Color(0xFF3D1535)],
                                stops: [0.0, 0.6, 1.0],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFB87AA0).withOpacity(
                                    _overlayActive ? 0.7 : 0.3,
                                  ),
                                  blurRadius: _overlayActive ? 60 : 30,
                                  spreadRadius: _overlayActive ? 20 : 5,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '瑞梅',
                                    style: TextStyle(
                                      color: Colors.white.withOpacity(0.9),
                                      fontSize: 36,
                                      fontWeight: FontWeight.w100,
                                    ),
                                  ),
                                  if (_overlayActive)
                                    Container(
                                      margin: const EdgeInsets.only(top: 4),
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Color(0xFF80E080),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 32),

                      // Status text
                      Text(
                        _overlayActive
                            ? 'Companion is active'
                            : allSet
                                ? 'Ready to summon'
                                : 'Complete setup first',
                        style: TextStyle(
                          color: _overlayActive
                              ? const Color(0xFF80E080)
                              : allSet
                                  ? const Color(0xFFD4A8C7)
                                  : Colors.grey,
                          fontSize: 14,
                          letterSpacing: 1,
                        ),
                      ),

                      const SizedBox(height: 20),

                      // Launch / dismiss button
                      GestureDetector(
                        onTap: () => _toggleOverlay(settings),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            gradient: LinearGradient(
                              colors: _overlayActive
                                  ? [const Color(0xFF5A2A4A), const Color(0xFF3A1A3A)]
                                  : allSet
                                      ? [const Color(0xFF8B4A6B), const Color(0xFF6B2A5A)]
                                      : [const Color(0xFF3A2A3A), const Color(0xFF2A1A2A)],
                            ),
                            border: Border.all(
                              color: _overlayActive
                                  ? const Color(0xFFD4A8C7).withOpacity(0.3)
                                  : const Color(0xFFD4A8C7).withOpacity(0.5),
                              width: 1,
                            ),
                            boxShadow: allSet
                                ? [BoxShadow(
                                    color: const Color(0xFF8B4A6B).withOpacity(0.4),
                                    blurRadius: 20,
                                    offset: const Offset(0, 4),
                                  )]
                                : [],
                          ),
                          child: Text(
                            _overlayActive
                                ? 'Dismiss Companion'
                                : _hasOverlayPermission
                                    ? 'Summon Ruan Mei'
                                    : 'Grant Overlay Permission',
                            style: const TextStyle(
                              color: Color(0xFFEDD5EA),
                              fontSize: 15,
                              letterSpacing: 1.5,
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ),
                      ),

                      if (!_hasOverlayPermission)
                        Padding(
                          padding: const EdgeInsets.only(top: 12),
                          child: TextButton(
                            onPressed: _requestOverlayPermission,
                            child: const Text(
                              'Tap above to open system permission dialog',
                              style: TextStyle(color: Colors.grey, fontSize: 11),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

                const Spacer(),

                // Bottom quick-setup chips
                if (!allSet)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        const Text('Complete these steps:',
                            style: TextStyle(color: Colors.grey, fontSize: 12)),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          alignment: WrapAlignment.center,
                          children: [
                            _SetupChip(
                              label: '🎭 Model',
                              done: settings.modelPath.isNotEmpty,
                              onTap: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
                            ),
                            _SetupChip(
                              label: '🤖 Claude Key',
                              done: settings.hasClaudeKey,
                              onTap: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
                            ),
                            _SetupChip(
                              label: '🎤 OpenAI Key',
                              done: settings.hasOpenAiKey,
                              onTap: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) => const SettingsScreen())),
                            ),
                            _SetupChip(
                              label: '🔊 Mic Permission',
                              done: false,
                              onTap: _requestMicPermission,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    super.dispose();
  }
}

class _DecorativeCircle extends StatelessWidget {
  final double size;
  final double opacity;
  const _DecorativeCircle({required this.size, required this.opacity});

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      border: Border.all(
        color: const Color(0xFFD4A8C7).withOpacity(opacity),
        width: 1,
      ),
    ),
  );
}

class _SetupChip extends StatelessWidget {
  final String label;
  final bool done;
  final VoidCallback onTap;
  const _SetupChip({required this.label, required this.done, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: done ? null : onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: done
            ? const Color(0xFF1A3A1A)
            : const Color(0xFF2D1A2D),
        border: Border.all(
          color: done ? const Color(0xFF4A8A4A) : const Color(0xFF6B3A5A),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: TextStyle(
            color: done ? const Color(0xFF80E080) : const Color(0xFFD4A8C7),
            fontSize: 12,
          )),
          if (done) ...[
            const SizedBox(width: 4),
            const Icon(Icons.check, size: 12, color: Color(0xFF80E080)),
          ],
        ],
      ),
    ),
  );
}
