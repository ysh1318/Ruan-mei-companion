import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  static const _keyClaudeApiKey = 'claude_api_key';
  static const _keyWhisperApiKey = 'whisper_api_key';
  static const _keyOpenAiApiKey = 'openai_api_key';
  static const _keyTtsVoice = 'tts_voice';
  static const _keyModelPath = 'model_path';
  static const _keyOverlaySize = 'overlay_size';
  static const _keyGravitySnap = 'gravity_snap';
  static const _keyClaudeModel = 'claude_model';
  static const _keySystemPrompt = 'system_prompt';

  String _claudeApiKey = '';
  String _openAiApiKey = '';    // Used for both Whisper STT and TTS
  String _ttsVoice = 'nova';    // OpenAI TTS voice
  String _modelPath = '';       // Path to .model3.json
  double _overlaySize = 200.0;  // Width of overlay in dp
  bool _gravitySnap = true;
  String _claudeModel = 'claude-opus-4-5';
  String _systemPrompt =
      'You are Ruan Mei from Honkai: Star Rail — brilliant, elegant, and softly mysterious. '
      'You study life forms with quiet fascination. You speak in a refined, warm, slightly '
      'philosophical way. Keep responses concise (1-3 sentences) since this is a voice chat. '
      'Occasionally mention your research or observations about the world around you.';

  String get claudeApiKey => _claudeApiKey;
  String get openAiApiKey => _openAiApiKey;
  String get ttsVoice => _ttsVoice;
  String get modelPath => _modelPath;
  double get overlaySize => _overlaySize;
  bool get gravitySnap => _gravitySnap;
  String get claudeModel => _claudeModel;
  String get systemPrompt => _systemPrompt;

  bool get hasClaudeKey => _claudeApiKey.isNotEmpty;
  bool get hasOpenAiKey => _openAiApiKey.isNotEmpty;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _claudeApiKey = prefs.getString(_keyClaudeApiKey) ?? '';
    _openAiApiKey = prefs.getString(_keyOpenAiApiKey) ?? '';
    _ttsVoice = prefs.getString(_keyTtsVoice) ?? 'nova';
    _modelPath = prefs.getString(_keyModelPath) ?? '';
    _overlaySize = prefs.getDouble(_keyOverlaySize) ?? 200.0;
    _gravitySnap = prefs.getBool(_keyGravitySnap) ?? true;
    _claudeModel = prefs.getString(_keyClaudeModel) ?? 'claude-opus-4-5';
    _systemPrompt = prefs.getString(_keySystemPrompt) ?? _systemPrompt;
    notifyListeners();
  }

  Future<void> setClaudeApiKey(String key) async {
    _claudeApiKey = key;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyClaudeApiKey, key);
    notifyListeners();
  }

  Future<void> setOpenAiApiKey(String key) async {
    _openAiApiKey = key;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyOpenAiApiKey, key);
    notifyListeners();
  }

  Future<void> setTtsVoice(String voice) async {
    _ttsVoice = voice;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyTtsVoice, voice);
    notifyListeners();
  }

  Future<void> setModelPath(String path) async {
    _modelPath = path;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyModelPath, path);
    notifyListeners();
  }

  Future<void> setOverlaySize(double size) async {
    _overlaySize = size;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyOverlaySize, size);
    notifyListeners();
  }

  Future<void> setGravitySnap(bool value) async {
    _gravitySnap = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyGravitySnap, value);
    notifyListeners();
  }

  Future<void> setClaudeModel(String model) async {
    _claudeModel = model;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyClaudeModel, model);
    notifyListeners();
  }

  Future<void> setSystemPrompt(String prompt) async {
    _systemPrompt = prompt;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keySystemPrompt, prompt);
    notifyListeners();
  }
}
